﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Villainy.Models
{
    public class Villain
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public string Powers { get; set; }
        public string Hobbies { get; set; }
    }
}
